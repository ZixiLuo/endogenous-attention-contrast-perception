function equality_endogenous_Letters(subjectid,start,over,blockNum)
%%  equality + stair (cRef = 0.6)

% last edition 28/9/2022 by luozixi    catch trialΪ��ĸ�ж����񣬴�ע�ⷶΧL��T��ĸ������Ϊ2:3/3:2

% subjectid='test_L';
% start=1;
% over=840;
% blockNum=6;

global inc background white
%% %%%%%%%%%%%%%%%%%%%%%%%%%% ������Ļ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HideCursor;
% Screen('Preference', 'SkipSyncTests', 1);   %��ʽʵ����ע�͵�
screenNumber=max(Screen('Screens'));

% ��Ļ��ɫ
white=WhiteIndex(screenNumber);
black=BlackIndex(screenNumber);
grey=round((white+black)/2);
if grey == white
    grey=white / 2;
end
inc = abs(white-grey);
background=grey;

% ��һ����Ļ
[w,rect]=Screen('OpenWindow',screenNumber,background);

% ��Ļ�����趨
AssertGLSL;                                                                 % Make sure this GPU supports shading at all
load('newclut');
load('oldclut');
Screen('LoadNormalizedGammaTable',screenNumber,newclut);                    % write CLUTs, screen normalization
Screen(w,'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);             % Enable alpha blending for typical drawing of masked textures
priorityLevel=MaxPriority(w);
Priority(priorityLevel);

% ��Ļˢ��Ƶ��
frameRate=Screen('FrameRate',w);
frameDura=1000/frameRate;
if  round(frameRate)~=100                                                   % ȷ��ˢ��Ƶ����100hz�����������,���Ե�ʱ��ע��
    quit
end

% frameDura = 10;%cnm��������ԣ���ʽ����ʱ��Ļؼ���
% ��Ļ�ߴ�
xcenter=rect(3)/2;                                                          % ��Ļ���ĺ�����
ycenter=rect(4)/2;


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% ���巴Ӧ���� %%%%%%%%%%%%%%%%%%%%%%%%%%%
KbName('UnifyKeyNames');
key_s=KbName('s');%F��һ����d����һ��;
key_d=KbName('d');%F��һ����d����һ��;

key_left=KbName('LeftArrow');         %��ĸL
key_right=KbName('RightArrow');       %��ĸT

key_q=KbName('q');
space=KbName('space');


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% �̼������趨 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% size
% �̼���С
pixelPerDegree = round(degree2pixel(1));

r = 1;
sizeGrating = round(degree2pixel(r));  % �̼��İ뾶

LetterSize = round(degree2pixel(0.34)); %��ĸ�뾶0.24

gap_size = round(degree2pixel(2)); %�뾶

%% fixation,�����߶����
Line_width = round(degree2pixel(0.1));
Line_length = round(degree2pixel(0.32));
Line_Vertical_rect = CenterRect([0 0 Line_width Line_length],rect);
Line_Horizental_rect = CenterRect([0 0 Line_length Line_width],rect);
Line_square_rect = CenterRect([0 0 Line_width Line_width],rect);

%% color
FixationColor = black;
CueColor = white;
WaitColor = background/2;

%% destinations
% gratings % 1 �� 2 ��
eccentricity2 = round(degree2pixel(4));
desCenter(:,:,1) = [xcenter-eccentricity2-sizeGrating ycenter-sizeGrating...
    xcenter-eccentricity2+sizeGrating ycenter+sizeGrating]; % left
desCenter(:,:,2) = [xcenter+eccentricity2-sizeGrating ycenter-sizeGrating...
    xcenter+eccentricity2+sizeGrating ycenter+sizeGrating]; % right

%% ��ʾ�������
%left
Cue_rect(1,:) = [Line_Horizental_rect(1) Line_Horizental_rect(2) Line_square_rect(1) Line_Horizental_rect(4)];
%neutral
Cue_rect(2,:) = [Line_Horizental_rect(1) Line_Horizental_rect(2) Line_Horizental_rect(3) Line_Horizental_rect(4)];
%right
Cue_rect(3,:) = [Line_square_rect(3) Line_Horizental_rect(2) Line_Horizental_rect(3) Line_Horizental_rect(4)];

%% Letters ����
%Сע�ⷶΧ
des_Small_Letters(:,:,1) = [xcenter-eccentricity2-LetterSize ycenter-LetterSize...
    xcenter-eccentricity2+LetterSize ycenter+LetterSize]; % left
des_Small_Letters(:,:,2) = [xcenter+eccentricity2-LetterSize ycenter-LetterSize...
    xcenter+eccentricity2+LetterSize ycenter+LetterSize]; % right

%��ע�ⷶΧ
%��ߵ�5��λ��
des_Large_Letters(:,:,1) = [xcenter-eccentricity2-LetterSize ycenter-LetterSize-gap_size...
    xcenter-eccentricity2+LetterSize ycenter+LetterSize-gap_size]; % left_top

des_Large_Letters(:,:,3) = [xcenter-eccentricity2-LetterSize-gap_size ycenter-LetterSize...
    xcenter-eccentricity2+LetterSize-gap_size ycenter+LetterSize]; % left_left

des_Large_Letters(:,:,5) = [xcenter-eccentricity2-LetterSize ycenter-LetterSize+gap_size...
    xcenter-eccentricity2+LetterSize ycenter+LetterSize+gap_size]; % left_bottom

des_Large_Letters(:,:,7) = [xcenter-eccentricity2-LetterSize+gap_size ycenter-LetterSize...
    xcenter-eccentricity2+LetterSize+gap_size ycenter+LetterSize]; % left_right

des_Large_Letters(:,:,9) = [xcenter-eccentricity2-LetterSize ycenter-LetterSize...
    xcenter-eccentricity2+LetterSize ycenter+LetterSize];  %left_middle

%�ұߵ�5��λ��
des_Large_Letters(:,:,2) = [xcenter+eccentricity2-LetterSize ycenter-LetterSize-gap_size...
    xcenter+eccentricity2+LetterSize ycenter+LetterSize-gap_size]; % right_top

des_Large_Letters(:,:,4) = [xcenter+eccentricity2-LetterSize+gap_size ycenter-LetterSize...
    xcenter+eccentricity2+LetterSize+gap_size ycenter+LetterSize]; % right_right

des_Large_Letters(:,:,6) = [xcenter+eccentricity2-LetterSize ycenter-LetterSize+gap_size...
    xcenter+eccentricity2+LetterSize ycenter+LetterSize+gap_size]; % right_bottom

des_Large_Letters(:,:,8) = [xcenter+eccentricity2-LetterSize-gap_size ycenter-LetterSize...
    xcenter+eccentricity2+LetterSize-gap_size ycenter+LetterSize]; % right_left

des_Large_Letters(:,:,10) = [xcenter+eccentricity2-LetterSize ycenter-LetterSize...
    xcenter+eccentricity2+LetterSize ycenter+LetterSize];        %right_middle
%% durations
% cue
cueDura = 400;
cueFrames = round(cueDura/frameDura);

% ISI
blankDura = 400; %��һ��Ϊ1000
blankFrames = round(blankDura/frameDura);    

% gratingDura
gratingDura = 40;
gratingFrames = round(gratingDura/frameDura);

% Catch trial duration
CatchDura = 190;   %��ע�ⷶΧʱ��Ϊ190ms
%CatchDura = 70;    %��ע�ⷶΧʱ��Ϊ190ms
CatchFrames = round(CatchDura/frameDura);
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%% grating %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ��դ�Աȶ�
cRef = 0.6;
minc = 0.2920;
maxc = 0.9696;
cTest0 = [minc maxc];
stepdir0 = [1 -1];

% �ռ�Ƶ��spatial frequency
cyclePerDegree = 4;
period = pixelPerDegree/cyclePerDegree; % how many pixels in one cycle
sf = 1/period;
angleRef = 0;
angleTest = 0;

%% %%%%%%%%%%%%%%%%%%%% letter��ز��� %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%% eye tracking setup %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% eye tracker setup
%%����֮ǰ��ʼ�����ڣ��ر� ɾ�����ܴ��ڵĴ��ڣ�
 IOPort('closeall');
%
% %%��������
%  [handle, errmsg] = IOPort('OpenSerialPort', 'com4' ,'BaudRate=256000 ReceiveTimeout=0.3');
 [handle, errmsg] = IOPort('OpenSerialPort', 'com9','BaudRate=115200 ReceiveTimeout=0.2'); %com���ֺ�BauRate�����ֶ�Ӧ������ĵ��Ե�COM�˿ںͲ�����
IOPort('Purge',handle); %������ж�д����������
% %%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%1 ����StimRD��stimuli ready���ź� �̼�������׼����
 StimRD='R';
 [nwritten, when, errmsg] = IOPort('Write', handle, StimRD);

% %%2 ����Tobii������׼�����ź�
while KbCheck; end
  TobReSig=0;
  qkey=KbName('q');
  keycode=zeros(1,256);
  while ~keycode(qkey) && ~TobReSig
      [data, when, errmsg] = IOPort('Read', handle,0,1);
      IOPort('Purge',handle); %������ж�д����������
      tobiiready=char(data);
      [keydown secs keycode]=KbCheck;
%
      if strcmp(tobiiready,'R')==1
          fprintf('Tobii is ready! \n');
          fprintf('------------------------------------------\n');
          TobReSig=1;
      else
          [nwritten, when, errmsg] = IOPort('Write', handle, StimRD);
          fprintf('%f Waiting for Tobii getting ready. \n', when);
          WaitSecs(1);
      end
  end



%% %%%%%%%%%%%%%%%%%%%%%%%  ����buildmatrix %%%%%%%%%%%%%%%%%%%%%%%%%
filename = ['data/',subjectid,'_paramatrix'];
load(filename);

% number of trials/per block;
npblock = length(paramatrix(:,1))/blockNum;

%%%%%%%%%%%%%%%%%%%%%%%%%% ������ĸͼƬ%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load Lmatrix;  %������Ҫ���ֵ�ͼ�����ؾ�������L
load Tmatrix;  %������Ҫ���ֵ�ͼ�����ؾ�������T

  ContrastLetter=0.5;

  LMatrix=(LMatrix/255)*background; %����ĸL����İ�ɫ�����ĻҶ�ֵ����Ϊ��Ļ��ɫ����
  LMatrix(find(LMatrix==0))=[ContrastLetter*background]; %������ĸ�ĶԱȶ�
  TMatrix=(TMatrix/255)*background; %����ĸT����İ�ɫ�����ĻҶ�ֵ����Ϊ��Ļ��ɫ����
  TMatrix(find(TMatrix==0))=[ContrastLetter*background];
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%% ѭ���ṹ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Screen('Flip',w); % ��߾���

for index = start:over
    
    trialtype = paramatrix(index,2); % 1~6
    initialdir = mod(trialtype,2)+1;
    
    indexDesCue = paramatrix(index,3)+2;
    indexDesRef = (paramatrix(index,4)+3)/2;%-1 1��1 2
    indexDesTest = (paramatrix(index,5)+3)/2; %-1 1��1 2
    
    fixDura = paramatrix(index,7);
    fixFrames = round(fixDura/frameDura);
    
    if paramatrix(index,17) == 1 % not catch trial
        indexMatrix = paramatrix(find(paramatrix(:,2)==trialtype),1); % �õ���trialtype��trial���к�
        % the first trial
        if paramatrix(indexMatrix,9)==0 % test contrast matrix
            paramatrix(index,9) = cTest0(initialdir);
            paramatrix(index,10) = log(cTest0(initialdir)*100);
            paramatrix(index,14) = stepdir0(initialdir);
        end
        
        cTest = paramatrix(index,9);
        
        MatrixTest = TextureCenter(sizeGrating,angleTest,cTest,sf);
        test = Screen('MakeTexture',w, MatrixTest);
        MatrixRef = TextureCenter(sizeGrating,angleRef,cRef,sf);
        ref = Screen('MakeTexture',w, MatrixRef);
        gratingTexture = [test ref];
        desGrating = reshape([desCenter(:,:,indexDesTest) desCenter(:,:,indexDesRef)],4,2);
        
        %% %%%%%%%%%%%%%%%%%% ����ע�ӵ㣬�ȴ����԰��¿ո����ʼ���� %%%%%%%%%%%%%%%%%
        Screen('FillRect',w,WaitColor,[Line_Vertical_rect',Line_Horizental_rect']);
        Screen('Flip', w);
        WaitSecs(0.5);
        [keyisdown,secs,keycode] = KbCheck;
        while keycode(space) == 0
            KbWait;
            [keyisdown,secs,keycode] = KbCheck;
            WaitSecs(0.001);
            
            % ��q���˳�
            if keycode(key_q)
                ShowCursor;
                Priority(0);
                             Screen('LoadNormalizedGammaTable',screenNumber,oldclut);
                Screen('CloseAll');
                            ExpOver='O';
                            [nwritten, when, errmsg] = IOPort('Write', handle, ExpOver);
                            fprintf('%f Experiment Over!!�� \n',when);
                            IOPort('closeall');
                ShowCursor; %
                return
            end
        end
        
            %%3 ����StaRec�źţ�Ҫ���۶��ǿ�ʼ��¼�۶�����
            StartRecord='B';
            [nwritten, when, errmsg] = IOPort('Write', handle, StartRecord);
            fprintf('Trial %i.\n',index);
            fprintf('%f Ask Tobii to begin to record. \n',when);
        
            %%4 ���ִ̼�
            fprintf('Presenting Stimuli ....... \n');
        
%         ���ո�ʼ
        if keycode(space)
            
            % 1. ע�ӵ����
            for r = 1:fixFrames
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                Screen('Flip',w);
            end
            
            
            % 2. cue����
            for r = 1:cueFrames
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                Screen('FillRect',w,CueColor, Cue_rect(indexDesCue,:));%��ʾ��
                Screen('Flip', w);
            end
            
            % 3. blank

            for r = 1:blankFrames
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                Screen('Flip',w);
            end

            % 4. �̼�����

            for r = 1: gratingFrames
                Screen('DrawTextures',w,gratingTexture,[],desGrating); % gratings
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                start_time = Screen('Flip',w);
            end

        end
        
            %%5 Tobii ֹͣ��¼
            StopRecord='S';
            [nwritten, when, errmsg] = IOPort('Write', handle, StopRecord);
            fprintf('%f Ask Tobii to stop recording. \n',when);
        
        %% %%%%%%%%%%%%%%%%%%%%%%%%% ��¼��Ӧ ������%%%%%%%%%%%%%%%%%%%%%%%%%%
        key = 0;
        
        while key == 0
            Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
            Screen('Flip',w);
            
            % ��Ӧ��¼
            [keyisdown, secs, keycode] =  KbCheck;
            over_time=GetSecs;
            WaitSecs(0.001);
            paramatrix(index,12) = (over_time-start_time)*1000;
            
            if keycode(key_d)
                
                key = 1;
                
                paramatrix(index,11) = -1;                                        %different response
                break
            elseif keycode(key_s)
                key = 1;
                paramatrix(index,11) = 1;                                       % same  response
                break
            end
        end
        %% beep
%         if beep == true
%             if round(cRef*100) == round(cTest*100)
%                 if paramatrix(index,11)==-1
%                     Beeper(800);
%                 end
%             elseif round(cTest*100)<=47 || round(cTest*100)>=76
%                 if  paramatrix(index,11)==1
%                     Beeper(400);
%                 end
%             end
%         end
        %% %% next trial %%%
        
        contrastMatrix = paramatrix(indexMatrix,9);
        responseMatrix = paramatrix(indexMatrix,11);
        dirMatrix = paramatrix(indexMatrix,14);
        [cTest2,stepdir2] = equalitystair(contrastMatrix,responseMatrix,dirMatrix,minc,maxc,cTest0(initialdir));
        index1=length(find(contrastMatrix~=0));      %��ǰ��trial��ţ������һ��ǿ�Ȳ�Ϊ0��trial��
        if index1 < size(contrastMatrix,1)
            index2 = indexMatrix(index1+1);              % next sequence index of this type
            paramatrix(index2,9) = cTest2;
            paramatrix(index2,10) = log(cTest2*100);
            paramatrix(index2,14) = stepdir2;
        end
        
        Screen('close',gratingTexture);                                         % close screen
        %% % catch trial
    elseif paramatrix(index,17) == -1
        indexDesCue = paramatrix(index,3)+2;  %cue condition[-1=left, 0=neutral, 1=right]  1  2  3
        indexDesCueLetter = (indexDesCue-1)./2+1; %1 2 
        indexDesNotCueLetter = 3-indexDesCueLetter;  % 2 1
        letter = paramatrix(index,8);  %cue_letter 1L 2T  ��ʾλ�õ�letter
        noletter = round(rand(1)+1);%δ����ʾλ�õ�letter�����������LҲ������T
     
        if  paramatrix(index,16) == 1    %%%Сע�ⷶΧ
           if letter == 1
              CueLetter=LMatrix;
           elseif letter == 2
              CueLetter=TMatrix;
           end
       
           if noletter==1
              NotCueLetter=LMatrix;
           elseif noletter == 2
              NotCueLetter=TMatrix;
           end
       
        CueTexture = Screen('MakeTexture',w, CueLetter);
        NotCueTexture= Screen('MakeTexture',w, NotCueLetter);
        LetterTexture = [CueTexture NotCueTexture];
        TrialdesLetter = reshape([des_Small_Letters(:,:,indexDesCueLetter) des_Small_Letters(:,:,indexDesNotCueLetter)],4,2);
       
        elseif  paramatrix(index,16) == -1  %%��ע�ⷶΧ
        indexDesCueLetter1=indexDesCueLetter;
        indexDesCueLetter2=indexDesCueLetter+2;
        indexDesCueLetter3=indexDesCueLetter+4;
        indexDesCueLetter4=indexDesCueLetter+6;
        indexDesCueLetter5=indexDesCueLetter+8;
        
        indexDesNotCueLetter1=indexDesNotCueLetter;
        indexDesNotCueLetter2=indexDesNotCueLetter+2;
        indexDesNotCueLetter3=indexDesNotCueLetter+4;
        indexDesNotCueLetter4=indexDesNotCueLetter+6;
        indexDesNotCueLetter5=indexDesNotCueLetter+8;
        
            
            if letter == 2                      %��ʾһ��������ĸ��T
               CueLessLetter=LMatrix;
               CueMoreLetter=TMatrix;
            
            elseif letter == 1                  %��ʾһ��������ĸ��L
               CueLessLetter=TMatrix;
               CueMoreLetter=LMatrix;
        
            end  
       
           if noletter == 2                     %������ʾһ��������ĸ��T
              NotCueLessLetter=LMatrix;
              NotCueMoreLetter=TMatrix;
              
           elseif noletter == 1                %������ʾһ��������ĸ��L
              NotCueLessLetter=TMatrix;
              NotCueMoreLetter=LMatrix;
    
           end
       
       CueLessTexture1 = Screen('MakeTexture',w, CueLessLetter);
       CueLessTexture2 = Screen('MakeTexture',w, CueLessLetter);
       CueMoreTexture1 = Screen('MakeTexture',w, CueMoreLetter);
       CueMoreTexture2 = Screen('MakeTexture',w, CueMoreLetter);
       CueMoreTexture3 = Screen('MakeTexture',w, CueMoreLetter);
       
       NotCueLessTexture1= Screen('MakeTexture',w, NotCueLessLetter);
       NotCueLessTexture2= Screen('MakeTexture',w, NotCueLessLetter);
       NotCueMoreTexture1= Screen('MakeTexture',w, NotCueMoreLetter);     
       NotCueMoreTexture2= Screen('MakeTexture',w, NotCueMoreLetter); 
       NotCueMoreTexture3= Screen('MakeTexture',w, NotCueMoreLetter); 
       
       CueLetterTexture0=[CueLessTexture1 CueLessTexture2 CueMoreTexture1 CueMoreTexture2 CueMoreTexture3];
       C0=randperm(size(CueLetterTexture0,2));  
       CueLetterTexture=CueLetterTexture0(:, C0);  
       
       NotCueLetterTexture0=[NotCueLessTexture1 NotCueLessTexture2 NotCueMoreTexture1 NotCueMoreTexture2 NotCueMoreTexture3];
       N0=randperm(size(NotCueLetterTexture0,2));  
       NotCueLetterTexture=NotCueLetterTexture0(:, N0);  
       
       LetterTexture = [CueLetterTexture NotCueLetterTexture];
       TrialdesLetter =  reshape([des_Large_Letters(:,:,indexDesCueLetter1) des_Large_Letters(:,:,indexDesCueLetter2) des_Large_Letters(:,:,indexDesCueLetter3) des_Large_Letters(:,:,indexDesCueLetter4) des_Large_Letters(:,:,indexDesCueLetter5) des_Large_Letters(:,:,indexDesNotCueLetter1) des_Large_Letters(:,:,indexDesNotCueLetter2) des_Large_Letters(:,:,indexDesNotCueLetter3) des_Large_Letters(:,:,indexDesNotCueLetter4) des_Large_Letters(:,:,indexDesNotCueLetter5)],4,10);        
       end
        %% %%%%%%%%%%%%%%%%%% ����ע�ӵ㣬�ȴ����԰��¿ո����ʼ���� %%%%%%%%%%%%%%%%%
        Screen('FillRect',w,WaitColor,[Line_Vertical_rect',Line_Horizental_rect']);
        Screen('Flip', w);
        WaitSecs(0.5);
        [keyisdown,secs,keycode] = KbCheck;
        while keycode(space) == 0
            KbWait;
            [keyisdown,secs,keycode] = KbCheck;
            WaitSecs(0.001);
            
            % ��q���˳�
            if keycode(key_q)
                ShowCursor;
                Priority(0);
                             Screen('LoadNormalizedGammaTable',screenNumber,oldclut);
                Screen('CloseAll');
                            ExpOver='O';
                            [nwritten, when, errmsg] = IOPort('Write', handle, ExpOver);
                            fprintf('%f Experiment Over!!�� \n',when);
                            IOPort('closeall');
                ShowCursor; %
                return
            end
        end
        
            %%3 ����StaRec�źţ�Ҫ���۶��ǿ�ʼ��¼�۶�����
            StartRecord='B';
            [nwritten, when, errmsg] = IOPort('Write', handle, StartRecord);
            fprintf('Trial %i.\n',index);
            fprintf('%f Ask Tobii to begin to record. \n',when);
        
            %%4 ���ִ̼�
            fprintf('Presenting Stimuli ....... \n');
        
        % ���ո�ʼ
        if keycode(space)
            
            % 1. ע�ӵ����
            for r = 1:fixFrames
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                Screen('Flip',w);
            end
            
            
            % 2. cue����
            for r = 1:cueFrames
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                Screen('FillRect',w,CueColor, Cue_rect(indexDesCue,:));%��ʾ��
                Screen('Flip', w);
            end
            
            % 3. blank
            for r = 1:blankFrames
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                Screen('Flip',w);
            end
            
            % 4. �̼�����
             
            for r = 1: CatchFrames
                Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
                Screen('DrawTextures',w,LetterTexture,[],TrialdesLetter); % letters
                start_time = Screen('Flip',w);
            end
             
        end
        
            %%5 Tobii ֹͣ��¼
            StopRecord='S';
            [nwritten, when, errmsg] = IOPort('Write', handle, StopRecord);
            fprintf('%f Ask Tobii to stop recording. \n',when);
        
        %% %%%%%%%%%%%%%%%%%%%%%%%%% ��¼��Ӧ ������%%%%%%%%%%%%%%%%%%%%%%%%%%
        key = 0;
        
        while key == 0
            Screen('FillRect',w,FixationColor,[Line_Vertical_rect',Line_Horizental_rect']);
            Screen('Flip',w);
            
            % ��Ӧ��¼
            [keyisdown, secs, keycode] =  KbCheck;
            over_time=GetSecs;
            WaitSecs(0.001);
            paramatrix(index,12) = (over_time-start_time)*1000;
            
            if keycode(key_left)
                key = 1;
                paramatrix(index,11) = 1;                                        % letter L
                break
            elseif keycode(key_right)
                key = 1;
                paramatrix(index,11) = 2;                                       % letter T
                break
            end
        end
        %% beep
%         if beep == true
            if paramatrix(index,11)~=paramatrix(index,8)%˵���жϳ���
                Beeper(800);
            end
%         end
    end
    
        %%6�����۶�������
        fprintf('%f Receiving data .......\n',when);
        XYPositionTimepoint=ReceiveEyemoveData(handle);
        PositionTime{index}=XYPositionTimepoint;
        save(['fixData/',subjectid,'_FixData'],'PositionTime','rect')
        % WaitSecs(1);
        fprintf('------------------------------------------\n');
    
    %% save
    save(filename,'paramatrix');
    
    % ��Ϣ
    if mod(index,npblock)==0 && index~=over
        Screen('DrawText',w,'Take A Rest',xcenter-80,ycenter, [0 0 0]);
        Screen('Flip',w);
        WaitSecs(5);%rest for 90s
        KbWait;
    elseif index==over
                ExpOver='O';
                [nwritten, when, errmsg] = IOPort('Write', handle, ExpOver);
                fprintf('%f Experiment Over!!�� \n',when);
                IOPort('closeall');
        
        Screen('DrawText',w,'The end. Thank You! ',xcenter-150,ycenter, [0 0 0]);
        Screen('Flip',w);
        WaitSecs(1);
        KbWait;
        break
    end
    
end

%% %%%%%%%%%%%%%%%%%%%%%% �رմ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Priority(0);
 Screen('LoadNormalizedGammaTable',screenNumber,oldclut);
Screen('CloseAll');
ShowCursor; % ��ʾ���

end









