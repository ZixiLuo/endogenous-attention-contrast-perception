 function buildmatrix_endoLetters(subjectid,attentional_focus)
%% buildmatrix for equality task + STAIR (cRef = 0.6)
% the origin code was written by Liufang Zhou, 22/12/2015
% the last edition is by luozixi, 22/09/2022

% column01 sequence number

% column02 trial type [cueValidity3*dir2=6]%
% column03 cue condition [-1=left, 0=neutral, 1=right]
% column04 ref location [-1=left 1=right]
% column05 test location [-1=left 1=right]
% column06 cue validity [1=ref cued, 0 = neutral cued, -1=test cued]

% column07 fixDura [400~600ms]
% column08 cue_letter [1 = letter L ��ĸL, 2 = letter T ��ĸT]
% %Сע�ⷶΧ��cueһ�����ĸ����ע�ⷶΧ��cueһ��������ĸ


% column09 test contrast(%)
% column10 test contrast(log)

% column11 response [1=same, -1=different] [1=L,2=T]
% column12 RT

% column13 initial direction
% column14 next step direction

% column15 
% column16 block_category[1= small focus, -1=large focus]
% column17 trial_category [1 = grating presented, -1 = LT presented]


%% ���´������ڳ������
% % 
%     subjectid = 'test_L';
%     attentional_focus=-1;
% % 
%% try����������ֹ���ݸ���
try
    filename = ['data/',subjectid,'_paramatrix'];
    load(filename);
    disp('the file already exist!')
catch
    %% parameter setting
    col = 17;
    
    des_cue = [-1 0 1];
    des_ref = [-1 1];
    cue_validity = [-1 0 1];
    cue_location = [-1 1];%catch trial û��������ʾ����
    dir = [-1 1];
    
    cue_form = [1 2];  %1=L; 2=T
    
    %% randomize
    [x1,x2,x3] = ndgrid(des_cue,des_ref,dir);                     % a matrix of randomized parameters
    combinedpara = [x1(:),x2(:),x3(:)];                                   % combined together
    
    paramatrix = zeros(length(combinedpara(:,1)),col);
    paramatrix(:,3) = combinedpara(:,1);
    paramatrix(:,4) = combinedpara(:,2);
    paramatrix(:,5) = -combinedpara(:,2);
    paramatrix(:,6) = combinedpara(:,1).*combinedpara(:,2);
    paramatrix(:,13) = combinedpara(:,3);
    
    paramatrix = sortrows(paramatrix,[4,6]);
    for r = 1:size(des_ref,2)               %size(des_cue,2),des-cue������
        for j = 1:size(cue_validity,2)
            for k = 1:size(dir,2)
                index = (j-1)*size(dir,2)+k;
                index1 = index+(r-1)*size(cue_validity,2)*size(dir,2);%index1Ϊʵ�ʵĵڼ���trial
                fixdura = round(rand(1)*200+400); % 400~600ms
                paramatrix(index1,7) = round(fixdura);
                paramatrix(index1,2) = index;
            end
        end
    end
    %��ʾ��λ��2*��ʾ����Ч�ԣ��̼���λ�ã�3*��ʼ���ݷ���2=12
    

    npcondition = 588; 
    paramatrix = repmat(paramatrix,npcondition/index1,1);               
    paramatrix(:,17) = 1;
    
    %% 30%���Դ�����Ϊcatch trial �ж�
    [x4,x5] = ndgrid(cue_form,cue_location);                     % a matrix of randomized parameters
    combinedpara = [x4(:),x5(:)];                                   % combined together
    
    paramatrix2 = zeros(length(combinedpara(:,1)),col);
    paramatrix2(:,17) = -1;
    paramatrix2(:,8) = combinedpara(:,1);
    paramatrix2(:,3) = combinedpara(:,2);

    %����Ҫ���ݷ����Դ������Ϊ0
    paramatrix2(:,2) = 0;
    npcondition = npcondition/0.7*0.3;
    paramatrix2 = repmat(paramatrix2,npcondition/size(paramatrix2,1),1);
    
    paramatrix = [paramatrix;paramatrix2];
    
    matrix = paramatrix;
    length0 = length(paramatrix);   %�У��� �����ֵ
    randIndex = randperm(length0);
    for r = 1:length0
        paramatrix(r,:) = matrix(randIndex(r),:);
        fixdura = round(rand(1)*200+400); % 400~600ms
        paramatrix(r,7) = round(fixdura);
    end                             % ����
    
  
    paramatrix(:,1) = 1:length(paramatrix(:,1));
    paramatrix(:,16)= attentional_focus;
    
    
    
    %% save
    filename = ['data/',subjectid,'_paramatrix'];
    save(filename,'paramatrix');
    clear
    
end
end

