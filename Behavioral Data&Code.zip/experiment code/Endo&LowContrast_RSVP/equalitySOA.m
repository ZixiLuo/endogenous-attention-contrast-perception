function equalitySOA(subjectid,SOA,start,over,num)
%%  equality + SOA + stair (cRef = 0.6)
%% add eyemove
% last modification 28/9/2018 by zxj
TrakingEyes=1;
global inc background white
%% %%%%%%%%%%%%%%%%%%%%%%%%%% ������Ļ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HideCursor;
% Screen('Preference', 'SkipSyncTests', 1);
screenNumber=max(Screen('Screens'));

% ��Ļ��ɫ
white=WhiteIndex(screenNumber);
black=BlackIndex(screenNumber);
grey=round((white+black)/2);
if grey == white
    grey=white / 2;
end
inc = abs(white-grey);
background=grey;

% ��һ����Ļ
[w,rect]=Screen('OpenWindow',screenNumber,background);

% ��Ļ�����趨
AssertGLSL;                                                                 % Make sure this GPU supports shading at all
load('newclut');
load('oldclut');
Screen('LoadNormalizedGammaTable',screenNumber,newclut);                    % write CLUTs, screen normalization
Screen(w,'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);             % Enable alpha blending for typical drawing of masked textures
priorityLevel=MaxPriority(w);
Priority(priorityLevel);

% ��Ļˢ��Ƶ��
frameRate=Screen('FrameRate',w);
frameDura=1000/frameRate;
if  round(frameRate)~=100                                                   % ȷ��ˢ��Ƶ����100hz�����������
    quit
end
% frameDura = 10;%cnm��������ԣ���ʽ����ʱ��Ļؼ���
% ��Ļ�ߴ�
xcenter=rect(3)/2;                                                          % ��Ļ���ĺ�����
ycenter=rect(4)/2;


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% ���巴Ӧ���� %%%%%%%%%%%%%%%%%%%%%%%%%%%
KbName('UnifyKeyNames');
key_f=KbName('f');%F��һ����J����һ��
key_j=KbName('j');

key_q=KbName('q');
space=KbName('space');


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% �̼������趨 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% cnm RSVP��ĸ������
rsvpnum = num;
zimu='BCOQSDGJX';%ʵ���г��ֵ�������ĸ
xshow = 0; %cnm ���ں���ʵ������X�ж�
%% size
% �̼���С
pixelPerDegree = round(degree2pixel(1));
sizeCue = round(degree2pixel(0.3));
sizeFix = round(degree2pixel(0.25));%cnm 0.2��0.25
linethickness = round(degree2pixel(0.15));
% sizeFixArea = round(degree2pixel(2));
r = 1.5;%cnm ��դ�뾶��Сû���ҵ�
sizeGrating = round(degree2pixel(r));  % �뾶
cueColor = black;
%% destinations
% ע�ӵ��λ��
% desFix = [xcenter-sizeFix/2,ycenter-sizeFix/2,xcenter+sizeFix/2,ycenter+sizeFix/2];
desFix(1,:) = [xcenter-sizeFix xcenter+sizeFix xcenter xcenter];
desFix(2,:) = [ycenter ycenter ycenter-sizeFix ycenter+sizeFix];

% gratings % 1 �� 2 ��
eccentricity2 = round(degree2pixel(5)); % ���ľ��� cnm 4��6
desCenter(:,:,1) = [xcenter-eccentricity2-sizeGrating ycenter-sizeGrating...
    xcenter-eccentricity2+sizeGrating ycenter+sizeGrating]; % left
desCenter(:,:,2) = [xcenter+eccentricity2-sizeGrating ycenter-sizeGrating...
    xcenter+eccentricity2+sizeGrating ycenter+sizeGrating]; % right

% cnm
% rsvp��λ�ã���ԭ�����cue��λ���޸�ΪRSVP��ĸ����λ�ã����ڻ�û�޸�
eccentricity1 = round(degree2pixel(0.8)); % ���ľ��� cnm r+0.3��sin(0.8/360*2*pi)*6
% eccentricity3 = round(degree2pixel((36-0.64)^0.5));
eccentricity3 = round(degree2pixel((25-0.64)^0.5));
desCue(:,:,1) = [xcenter-eccentricity3 ycenter-eccentricity1]; % left
desCue(:,:,2) = [xcenter+eccentricity3 ycenter-eccentricity1]; % right
% desCue(:,:,2) = [xcenter ycenter]; % center
% desCue(:,:,3) = [xcenter+eccentricity2 ycenter-eccentricity1]; % right


%% durations
% rest
restDura = 1500;
restFrames = round(restDura/frameDura);

% cue
cueDura = 400;%gly
cueFrames = round(cueDura/frameDura);

% gratingDura
gratingDura = 40;
% gratingDura = 80;
% gratingDura = 1000;
gratingFrames = round(gratingDura/frameDura);

%cnm
% RSVPע��ʱ��
rsvpDura = 1200;
% rsvpDura = 12000;
single_rsvpDura = rsvpDura/rsvpnum;
rsvpFrames = round(rsvpDura/frameDura);
single_rsvpFrames = round(single_rsvpDura/frameDura);
% testDura = 200;
% testFrames = round(testDura/frameDura);
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%% grating %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ��դ�Աȶ�
cRef = 0.25;
minc = 0.09;
maxc = 0.68;
% cRef = 0.15;
% minc = 0.07;
% maxc = 0.23;
% cRef = 0.6;
% % minc = 0.4;
% % maxc = 0.8;
% minc = 0.2920;
% maxc = 0.9696;
% cRef = 0.4;
% minc = 0.179735;
% maxc = 0.890235;
cTest0 = [minc maxc];
stepdir0 = [1 -1];

% �ռ�Ƶ��spatial frequency
cyclePerDegree = 4;
period = pixelPerDegree/cyclePerDegree; % how many pixels in one cycle
sf = 1/period;
angleRef = 0;
angleTest = 0;

%% %%%%%%%%%%%%%%%%%%%%%%%  ����buildmatrix %%%%%%%%%%%%%%%%%%%%%%%%%
% buildmatrixSOA(subjectid,SOA);
% cnm������Ĵ���Ϊ360�Σ����滹Ҫ�޸�
filename = ['data/',subjectid,'_',num2str(SOA),'_paramatrix'];
load(filename);

blockNum = 4;
npblock = length(paramatrix(:,1))/blockNum;
%% cnm ����ĸ�����е�����0ȫ���滻Ϊ9
[x_x,x_y] = find(paramatrix(:,20:19+2*rsvpnum)==0);
x_location = [x_x,19+x_y];
for i = 1:length(x_x)
    paramatrix(x_location(i,1),x_location(i,2)) = 9;
end

%% %%%%%%%%%%%%%%%%%%%% eye tracking setup %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if TrakingEyes==1 %��Ҫ��¼�۶�
    % eye tracker setup
    %%0 ����֮ǰ��ʼ�����ڣ��ر� ɾ�����ܴ��ڵĴ��ڣ�
    IOPort('closeall');

    %%��������
%      [handle, errmsg] = IOPort('OpenSerialPort', 'com3','BaudRate=256000 ReceiveTimeout=0.3');
    [handle, errmsg] = IOPort('OpenSerialPort', 'com2','BaudRate=512000 ReceiveTimeout=0.2');
    IOPort('Purge',handle); %������ж�д����������
    %%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %1 ����StimRD��stimuli ready���ź� �̼�������׼����
    StimRD='R';
    [nwritten, when, errmsg] = IOPort('Write', handle, StimRD);

    %%2 ����Tobii������׼�����ź�
    while KbCheck; end
    TobReSig=0;
    qkey=KbName('q');
    keycode=zeros(1,256);
    while ~keycode(qkey) && ~TobReSig
        [data, when, errmsg] = IOPort('Read', handle,0,1);
        IOPort('Purge',handle); %������ж�д����������
        tobiiready=char(data);
        [keydown secs keycode]=KbCheck;

        if strcmp(tobiiready,'R')==1
            fprintf('Tobii is ready! \n');
            fprintf('------------------------------------------\n');
            TobReSig=1;
        else
            [nwritten, when, errmsg] = IOPort('Write', handle, StimRD);
            fprintf('%f Waiting for Tobii getting ready. \n', when);
            WaitSecs(1);
        end
    end
end
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%% ѭ���ṹ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Screen('Flip',w); % ��߾���
for index = start:over

    trialtype = paramatrix(index,2); % 1~20
    initialdir = mod(trialtype,2)+1;

    indexDesCue = paramatrix(index,3);
    indexDesRef = paramatrix(index,4);
    indexDesTest = paramatrix(index,5);

    fixDura = paramatrix(index,7);
    fixFrames = round(fixDura/frameDura);

    SOA = paramatrix(index,8);
    blankDura = SOA-cueDura;
    blankFrames = round(blankDura/frameDura);

    indexMatrix = paramatrix(find(paramatrix(:,2)==trialtype),1); % �õ���trialtype��trial���к�
    % the first trial
    if paramatrix(indexMatrix,9)==0 % test contrast matrix
        paramatrix(index,9) = cTest0(initialdir);%����trialtype������ż���ĸı䣬��ʼ�ĶԱȶ�ǿ��Ҳ������ͬ
        paramatrix(index,10) = log(cTest0(initialdir)*100);
        paramatrix(index,14) = stepdir0(initialdir);
    end

    cTest = paramatrix(index,9);

    MatrixTest = TextureCenter(sizeGrating,angleTest,cTest,sf);
    test = Screen('MakeTexture',w, MatrixTest);
    MatrixRef = TextureCenter(sizeGrating,angleRef,cRef,sf);
    ref = Screen('MakeTexture',w, MatrixRef);
    gratingTexture = [test ref];
    desGrating = reshape([desCenter(:,:,indexDesTest) desCenter(:,:,indexDesRef)],4,2);



    %% %%%%%%%%%%%%%%%%%% ����ע�ӵ㣬�ȴ����԰��¿ո����ʼ���� %%%%%%%%%%%%%%%%%
    %     Screen('FillRect', w, 100, desFix);
    for r = 1:restFrames
       Screen('DrawText',w,'REST',xcenter-24,ycenter-12, [0 0 0]);
       Screen('Flip', w);
    end
    Screen('DrawLines',w,desFix,linethickness,80,[],1);
    Screen('Flip', w);
    WaitSecs(0.2);
    [keyisdown,secs,keycode] = KbCheck;
    while keycode(space) == 0
        KbWait;
        [keyisdown,secs,keycode] = KbCheck;
        WaitSecs(0.001);

        % ��q���˳�
        if keycode(key_q)
            ShowCursor;
            Priority(0);
            Screen('LoadNormalizedGammaTable',screenNumber,oldclut);
            Screen('CloseAll');
                        ExpOver='O';
                        [nwritten, when, errmsg] = IOPort('Write', handle, ExpOver);
                        fprintf('%f Experiment Over!!�� \n',when);
                        IOPort('closeall');
            ShowCursor; %
            return
        end
    end

    %%3 ����StaRec�źţ�Ҫ���۶��ǿ�ʼ��¼�۶�����
    StartRecord='B';
    [nwritten, when, errmsg] = IOPort('Write', handle, StartRecord);
    fprintf('Trial %i.\n',index);
    fprintf('%f Ask Tobii to begin to record. \n',when);

    %%4 ���ִ̼�
    fprintf('Presenting Stimuli ....... \n');

    % ���ո�ʼ
    if keycode(space)

        % 1. ע�ӵ����
        for r = 1:fixFrames
            %             Screen('FillRect', w, black, desFix);
            Screen('DrawLines',w,desFix,linethickness,black,[],1);
            Screen('Flip',w);
        end


        % 2. cue����gly
        for r = 1:cueFrames
            if indexDesCue == 1
                Screen('DrawLines',w,desFix,linethickness,black,[],1);
                Screen('DrawLine',w,white,xcenter-sizeFix,ycenter,xcenter-linethickness/2,ycenter,linethickness);
            elseif indexDesCue == 2
                Screen('DrawLines',w,desFix,linethickness,black,[],1);
                Screen('DrawLine',w,white,xcenter+sizeFix,ycenter,xcenter+linethickness/2,ycenter,linethickness);
            end
            Screen('Flip', w);
        end

        %cnm
        % 2.5 RSVP��ĸ������
        for i = 1:rsvpnum %ÿ����ĸ���γ���
            left_char = zimu(1,paramatrix(index,19+i));
            right_char = zimu(1,paramatrix(index,19+rsvpnum+i));%�õ�Ҫ���ֵ�������ĸ
            for r = 1:single_rsvpFrames
                Screen('DrawLines',w,desFix,linethickness,black,[],1);
                Screen('DrawText',w,left_char,desCue(:,1,1)-10,desCue(:,2,1)-10,white,degree2pixel(0.8));
                Screen('DrawText',w,right_char,desCue(:,1,2)-10,desCue(:,2,2)-10,white,degree2pixel(0.8));%cnm ��ĸ��λ�û���Ҫ����
                Screen('Flip', w);
            end
        end


        % 3. blank
        for r = 1:blankFrames
            %             Screen('FillRect', w, black, desFix);
            Screen('DrawLines',w,desFix,linethickness,black,[],1);
            Screen('Flip',w);
        end

        % 4. �̼�����
        for r = 1: gratingFrames
            Screen('DrawTextures',w,gratingTexture,[],desGrating); % gratings
            %             Screen('FillRect', w, black, desFix);
            Screen('DrawLines',w,desFix,linethickness,black,[],1);
            start_time = Screen('Flip',w);
        end
    end

    %%5 Tobii ֹͣ��¼
    if TrakingEyes==1 %��Ҫ��¼�۶�
        StopRecord='S';
        [nwritten, when, errmsg] = IOPort('Write', handle, StopRecord);
        fprintf('%f Ask Tobii to stop recording. \n',when);
    end
    %% %%%%%%%%%%%%%%%%%%%%%%%%% ��¼��Ӧ ������%%%%%%%%%%%%%%%%%%%%%%%%%%
    key = 0;

    while key == 0
        %         Screen('FillRect', w, black, desFix);
        Screen('DrawLines',w,desFix,linethickness,black,[],1);
        Screen('Flip',w);

        % ��Ӧ��¼
        [keyisdown, secs, keycode] =  KbCheck;
        over_time=GetSecs;
        WaitSecs(0.001);
        paramatrix(index,12) = (over_time-start_time)*1000;

        if keycode(key_f)
            key = 1;
            paramatrix(index,11) = 1;                                        % same response
            break
        elseif keycode(key_j)
            key = 1;
            paramatrix(index,11) = -1;                                       % different response
            break
            %cnm
            %���ӿո���жϣ����X�����򰴿ո��
        elseif keycode(space)
            key = 1;
            paramatrix(index,11) = 0;
            break
        end
    end
    %% %% next trial %%%
    %cnm
    %�Խ�������жϣ�������԰��˿ո��������ĸ������X���֣���ԱȶȲ������ֲ���
    contrastMatrix = paramatrix(indexMatrix,9);
    index1=length(find(contrastMatrix~=0));      %��ǰ��trial���
    if paramatrix(index,15) == 0 || paramatrix(index,11)==0
        paramatrix(index,2) = -1 ;%cnm ��FA��M�����д�ԭ������ɾ���������ͱ��Ϊ-1
        indexMatrix = paramatrix(find(paramatrix(:,2)==trialtype),1); % ���µõ���trialtype��trial���к�
    end
    contrastMatrix = paramatrix(indexMatrix,9);
    responseMatrix = paramatrix(indexMatrix,11);
    dirMatrix = paramatrix(indexMatrix,14);
    index1=length(find(contrastMatrix~=0));      %��ǰ��trial���
    %     [cTest2,stepdir2] = equalitystair(contrastMatrix,responseMatrix,dirMatrix,minc,maxc,cTest0(initialdir));
    cTest2 = EJupdownstaircase(contrastMatrix,responseMatrix,minc,maxc,cTest0(initialdir));
    if index1 < size(contrastMatrix,1)
        index2 = indexMatrix(index1+1);              % next sequence index of this type
        paramatrix(index2,9) = cTest2;
        paramatrix(index2,10) = log(cTest2*100);
        %         paramatrix(index2,14) = stepdir2;
    end
    %% save
    save(filename,'paramatrix');

    %     %%6�����۶�������
    if TrakingEyes==1 %��Ҫ��¼�۶�
        fprintf('%f Receiving data .......\n',when);
        XYPositionTimepoint=ReceiveEyemoveData(handle);
        PositionTime{index}=XYPositionTimepoint;
        save(['data/',subjectid,'_FixData'],'PositionTime','rect')
        % WaitSecs(1);
        fprintf('------------------------------------------\n');
    end


    % ��Ϣ
    if mod(index,npblock)==0 && index~=over
        Screen('DrawText',w,'Take A Rest',xcenter-80,ycenter, [0 0 0]);
        Screen('Flip',w);
        WaitSecs(5);
        KbWait;
    elseif index==over
        ExpOver='O';
        [nwritten, when, errmsg] = IOPort('Write', handle, ExpOver);
        fprintf('%f Experiment Over!!�� \n',when);
        IOPort('closeall');

        Screen('DrawText',w,'The end. Thank You! ',xcenter-150,ycenter, [0 0 0]);
        Screen('Flip',w);
        WaitSecs(1);
        KbWait;
        break
    end

    Screen('close',gratingTexture);                                         % close screen

end

%% %%%%%%%%%%%%%%%%%%%%%% �رմ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Priority(0);
Screen('LoadNormalizedGammaTable',screenNumber,oldclut);
Screen('CloseAll');
ShowCursor; % ��ʾ���

end









