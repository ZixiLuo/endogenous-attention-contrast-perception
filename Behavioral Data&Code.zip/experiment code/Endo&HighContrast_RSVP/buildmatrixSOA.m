function buildmatrixSOA(subjectid,SOA,num)
%% buildmatrix for equality task + SOA + STAIR (cRef = 0.6)
% written by Liufang Zhou, 22/12/2015

% column01 sequence number

% column02 trial type [cueValidity2*dir2*SOA5=30]%
% column03 cue location [1=left, 2=right]
% column04 ref location [1=left 2=right]
% column05 test location [1=left 2=right]
% column06 cue validity [1=ref cued, -1=test cued]

% column07 fixDura [400~600ms]
% column08 SOA [70ms 120ms 200ms 300ms 500ms]

% column09 test contrast(%)
% column10 test contrast(log)

% column11 response [1=same, -1=different]
% column12 RT

% column13 initial direction
% column14 next step direction 

% cnm column15 ����X����
% cnm column16 X��λ��
% cnm colunmn17 �����۶���1Ϊ���۶���

%% parameter setting
col = 17+2+16;%cnm 17��+2��+16����ĸ

des_cue = [-1 1];
des_ref = [-1 1];
cue_validity = [-1 1];
% SOA = [70 120 200 300 500];
% SOA = [70 120 250 500 800];
% SOA = 120;
dir = [-1 1];
whetherx = [0 1 1 1 1];%cnm 0��X���֣�����û��X����

%% randomize
[x1,x2,x3,x4,x5] = ndgrid(des_cue,des_ref,SOA,dir,whetherx);                     % a matrix of randomized parameters
combinedpara = [x1(:),x2(:),x3(:),x4(:),x5(:)];                                   % combined together

paramatrix = zeros(length(combinedpara(:,1)),col);
paramatrix(:,3) = combinedpara(:,1)/2+1.5;
paramatrix(:,4) = combinedpara(:,2)/2+1.5;
paramatrix(:,5) = -combinedpara(:,2)/2+1.5;%��-1��1ת��Ϊ1��2����
paramatrix(:,6) = combinedpara(:,1).*combinedpara(:,2);
paramatrix(:,8) = combinedpara(:,3);
paramatrix(:,13) = combinedpara(:,4);
paramatrix(:,15) = combinedpara(:,5);

paramatrix = sortrows(paramatrix,[3,8,6,14]);
for r = 1:size(des_cue,2)               %size(des_cue,2),des-cue������
    for i = 1:size(SOA,2)
        for j = 1:size(cue_validity,2)
            for k = 1:size(dir,2)
                for l = 1:size(whetherx,2)
                        index = (i-1)*size(cue_validity,2)*size(dir,2)*size(whetherx,2)+...
                            (j-1)*size(dir,2)*size(whetherx,2)+(k-1)*size(whetherx,2)+l;
                        index1 = index+(r-1)*size(SOA,2)*size(cue_validity,2)*size(dir,2)*size(whetherx,2);
                        if ismember(index,[3,5,7,9])%��ԭ���н���������20��trialtypeת��Ϊ8��������X���ֵ����н����˺ϲ�4+��20-4��/4=8
                            index = 3;
                        elseif ismember(index,[4,6,8,10])
                            index = 4;
                        elseif ismember(index,[11])
                            index = 5;
                        elseif ismember(index,[12])
                            index = 6;
                        elseif ismember(index,[13,15,17,19])
                            index = 7;
                        elseif ismember(index,[14,16,18,20])
                            index = 8;
                        end
                        paramatrix(index1,2) = index;
                        paramatrix(index1,20:(2*num+19)) = [randperm(num) randperm(num)];%���������ĸ�ľ���
                end
            end
        end
    end
end
            %��ʾ��λ��2*��ʾ����Ч�ԣ��̼���λ�ã�2*��ʼ�Աȶȷ���2*����X����5=40
    
npcondition = 180; % 2*2*2*5��40��Ϊ1��block
paramatrix = repmat(paramatrix,npcondition/(size(des_cue,2)*size(dir,2)*size(whetherx,2)),1);               %����Ϊ360��
for i = 1:360
    index1 = i;
    if paramatrix(index1,15) == 0
        rand_num = randperm(num);
        paramatrix(index1,19+(paramatrix(index1,3)-1)*num+rand_num(1)) = 0;
    end
end
matrix = paramatrix;         
length0 = length(paramatrix);   %�У��� �����ֵ
randIndex = randperm(length0); 
for r = 1:length0
    paramatrix(r,:) = matrix(randIndex(r),:);
end                             %�� ����
% for r = 1:length0
%     paramatrix(r,:) = matrix(randIndex(r),:);
% end                             %�� ����

fixdura = rand([1,length0])*200+400; % range from 400ms to 600ms
paramatrix(:,7) = round(fixdura);
paramatrix(:,1) = 1:length(paramatrix(:,1));



%% save
filename = ['data/',subjectid,'_',num2str(SOA),'_paramatrix'];
save(filename,'paramatrix');
clear 

end

