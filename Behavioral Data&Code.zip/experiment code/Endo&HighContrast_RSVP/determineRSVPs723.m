function RSVPs= determineRSVPs723(trials, rate, smallest, largest,filename)
%% try to determine the numbers of RSVP letters in the experiment
%written by ZXJ ,2018/7/15
%last modification 2018/7/23
%function determineRSVPs return to the number of RSVP lehowtters
%trials means how many trials in each condition
%rate means Probability of X occurrence 
%smallest means the smallest number of RSVP letter
%largest means the largest number of RSVP letter
%w means Window
filename = strcat('data\determineRSVPS\',filename);
global inc background white
HideCursor;
screenNumber=max(Screen('Screens'));
% ��Ļ��ɫ
white=WhiteIndex(screenNumber);
black=BlackIndex(screenNumber);
grey=round((white+black)/2);
if grey == white
    grey=white / 2;
end
inc = abs(white-grey);
background=grey;

% ��һ����Ļ
[w,rect]=Screen('OpenWindow',screenNumber,background);

% ��Ļ�����趨
AssertGLSL;                                                                 % Make sure this GPU supports shading at all
load('newclut');
load('oldclut');
Screen('LoadNormalizedGammaTable',screenNumber,newclut);                    % write CLUTs, screen normalization
Screen(w,'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);             % Enable alpha blending for typical drawing of masked textures
priorityLevel=MaxPriority(w);
Priority(priorityLevel);

frameDura = 10;
xcenter=rect(3)/2;                                                          % ��Ļ���ĺ�����  
ycenter=rect(4)/2;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% ���巴Ӧ���� %%%%%%%%%%%%%%%%%%%%%%%%%%%
KbName('UnifyKeyNames');
key_f=KbName('f');%F��һ����J����һ��
key_j=KbName('j');
key_q=KbName('q');
space=KbName('space');

zimu='BCOQSDGJX';
%% size
% �̼���С
pixelPerDegree = round(degree2pixel(1));
sizeFix = round(degree2pixel(0.25));
linethickness = round(degree2pixel(0.15));
r = 1.5;
sizeGrating = round(degree2pixel(r));  % �뾶
%% destinations
% ע�ӵ��λ��
desFix(1,:) = [xcenter-sizeFix xcenter+sizeFix xcenter xcenter];
desFix(2,:) = [ycenter ycenter ycenter-sizeFix ycenter+sizeFix];


% gratings % 1 �� 2 ��
eccentricity2 = round(degree2pixel(5)); % ���ľ���
desCenter(:,:,1) = [xcenter-eccentricity2-sizeGrating ycenter-sizeGrating...
    xcenter-eccentricity2+sizeGrating ycenter+sizeGrating]; % left
desCenter(:,:,2) = [xcenter+eccentricity2-sizeGrating ycenter-sizeGrating...
    xcenter+eccentricity2+sizeGrating ycenter+sizeGrating]; % right

% rsvp��λ�ã���ԭ�����cue��λ���޸�ΪRSVP��ĸ����λ�ã����ڻ�û�޸�
eccentricity1 = round(degree2pixel(0.8)); % ���ľ��� cnm r+0.3��sin(0.8/360*2*pi)*6
eccentricity3 = round(degree2pixel((25-0.64)^0.5));
desCue(:,:,1) = [xcenter-eccentricity3 ycenter-eccentricity1]; % left
desCue(:,:,2) = [xcenter+eccentricity3 ycenter-eccentricity1]; % right

%% durations
% rest
restDura = 1500;
restFrames = round(restDura/frameDura);

% cue
cueDura = 400;
cueFrames = round(cueDura/frameDura);

% gratingDura
gratingDura = 40;
gratingFrames = round(gratingDura/frameDura);

% ��դ�Աȶ�
cRef=0.6;

minc = 0.2920;
maxc = 0.9696;
cTest0 = [minc maxc];
stepdir0 = [1 -1];

% �ռ�Ƶ��spatial frequency
cyclePerDegree = 4;
period = pixelPerDegree/cyclePerDegree; % how many pixels in one cycle
sf = 1/period;
angleTest = 0;
angleRef = 0;


SOA = 500;  %cnm
blankDura = SOA-cueDura;
blankFrames = round(blankDura/frameDura);

%% build a matrix
% column01 sequence number
% column02 cue type [1=left,0=right]
% column03 whether x appears [1=yes, 0=no]
% column04 response[0=no appear,1=appear]
% column05 right or wrong[0=wrong 1=right]
% column06 number of letters in RSVP[from smallest to largest]
% column07 initial from small or large[0=from large to small 1=from small to large]
% column08 fixtime [400~600]


matrix=zeros(trials,8);
for i=1:trials
    if i<=trials/2
        matrix(i,2)=1;
    end
    if (i>=0 && i<=trials/2*rate) ||(i>trials/2 && i<=trials/2*rate+trials/2) 
        matrix(i,3)=1;
    end
    matrix(i,8)=400+randi(200);
end

randnum=randperm(trials);
for i=1:trials/2
    matrix(randnum(i),7)=1;
end

randIndex = randperm(trials);
matrix=matrix(randIndex,:);
for i=1:trials
    matrix(i,1)=i;
end

%% %%%%%%%%%%%%%%%%%%%%formal experiment%%%%%%%%%%%%%%%%%%%%
for i=1:trials
    fixDura = matrix(i,8);
    fixFrames = round(fixDura/frameDura);
    cTest=0.3+randi(100)/100*0.6;
    indexMatrix = matrix(find(matrix(:,7)==matrix(i,7)),1); % �õ���trialtype��trial���к�
    strengthmatrix=matrix(indexMatrix,6);
    responsematrix=matrix(indexMatrix,5);
    if matrix(i,7)==0
        initialstrength=8;
    else initialstrength=5;
    end
    matrix(i,6)=updownstaircase1(strengthmatrix,responsematrix,smallest,largest,initialstrength);

    MatrixTest = TextureCenter(sizeGrating,angleTest,cTest,sf);
    test = Screen('MakeTexture',w, MatrixTest);
    MatrixRef = TextureCenter(sizeGrating,angleRef,cRef,sf);
    ref = Screen('MakeTexture',w, MatrixRef);
    gratingTexture = [test ref];
    indexDesTest=randi(2);
    if indexDesTest==1
        indexDesRef=2;
    else indexDesRef=1;
    end
    desGrating = reshape([desCenter(:,:,indexDesTest) desCenter(:,:,indexDesRef)],4,2);
    
 %% %%%%%%%%%%%%%%%%%% ����ע�ӵ㣬�ȴ����԰��¿ո����ʼ���� %%%%%%%%%%%%%%%%%
    for r = 1:restFrames
       Screen('DrawText',w,'REST',xcenter-24,ycenter-12, [0 0 0]);
       Screen('Flip', w);
    end
    
    Screen('DrawLines',w,desFix,linethickness,80,[],1);
    Screen('Flip', w);
    WaitSecs(0.2);
    [keyisdown,secs,keycode] = KbCheck;
    while keycode(space) == 0
        KbWait;
        [keyisdown,secs,keycode] = KbCheck;
        WaitSecs(0.001);
        
        % ��q���˳�
        if keycode(key_q)
            ShowCursor;
            Priority(0);
            Screen('LoadNormalizedGammaTable',screenNumber,oldclut);
            Screen('CloseAll');
            %             ExpOver='O';
            %             [nwritten, when, errmsg] = IOPort('Write', handle, ExpOver);
            %             fprintf('%f Experiment Over!!�� \n',when);
            %             IOPort('closeall');
            ShowCursor; %
            return
        end
    end
    
    %     %%3 ����StaRec�źţ�Ҫ���۶��ǿ�ʼ��¼�۶�����
    %     StartRecord='B';
    %     [nwritten, when, errmsg] = IOPort('Write', handle, StartRecord);
    %     fprintf('Trial %i.\n',index);
    %     fprintf('%f Ask Tobii to begin to record. \n',when);
    
    %     %%4 ���ִ̼�
    %     fprintf('Presenting Stimuli ....... \n');
    %
    % ���ո�ʼ
    if keycode(space)
        % 1. ע�ӵ����

        for r = 1:fixFrames
            Screen('DrawLines',w,desFix,linethickness,black,[],1);
            Screen('Flip',w);
        end
        
        % 2. cue����
        for r = 1:cueFrames
            if matrix(i,2) == 1
                Screen('DrawLines',w,desFix,linethickness,black,[],1);
                Screen('DrawLine',w,white,xcenter-sizeFix,ycenter,xcenter-linethickness/2,ycenter,linethickness);
            elseif matrix(i,2) == 0
                Screen('DrawLines',w,desFix,linethickness,black,[],1);
                Screen('DrawLine',w,white,xcenter+sizeFix,ycenter,xcenter+linethickness/2,ycenter,linethickness);
            end;
            Screen('Flip',w);
        end
        
        % 3. RSVP��ĸ��
        orderleft=randperm(8);
        orderright=randperm(8);
        if matrix(i,2)==1 && matrix(i,3)==1
            orderleft(randi(matrix(i,6)))=9;
        elseif matrix(i,2)==0 && matrix(i,3)==1
            orderright(randi(matrix(i,6)))=9;
        end
        for r = 1:matrix(i,6) %ÿ����ĸ���γ���
            left_char = zimu(1,orderleft(r));
            right_char =zimu(1,orderright(r));%�õ�Ҫ���ֵ�������ĸ
            for t = 1: round(1200/matrix(i,6)/frameDura);
                Screen('DrawLines',w,desFix,linethickness,black,[],1);
                Screen('DrawText',w,left_char,desCue(:,1,1)-10,desCue(:,2,1)-10,white,degree2pixel(0.8));
                Screen('DrawText',w,right_char,desCue(:,1,2)-10,desCue(:,2,2)-10,white,degree2pixel(0.8));%cnm ��ĸ��λ�û���Ҫ����
                Screen('Flip', w);
            end
        end
        
        % 4. blank
        for r = 1:blankFrames
            %             Screen('FillRect', w, black, desFix);
            Screen('DrawLines',w,desFix,linethickness,black,[],1);
            Screen('Flip',w);
        end
        
        % 5. �̼�����
        for r = 1: gratingFrames
            Screen('DrawTextures',w,gratingTexture,[],desGrating); % gratings
            %             Screen('FillRect', w, black, desFix);
            Screen('DrawLines',w,desFix,linethickness,black,[],1);
            start_time = Screen('Flip',w);
        end
    end
    %% %%%%%%%%%%%%%%%%%%%%%%%%% ��¼��Ӧ ������%%%%%%%%%%%%%%%%%%%%%%%%%%
    key = 0;
    
    while key == 0
        Screen('DrawLines',w,desFix,linethickness,black,[],1);
        Screen('Flip',w);
        
%         ��Ӧ��¼
        [keyisdown, secs, keycode] =  KbCheck;
        if keycode(key_f)
            key = 1;
            break
        elseif keycode(key_j)
            key = 1;
            break
        elseif keycode(space)
            key=1;
            matrix(i,4)=1;
            break;
        end
    end
%       �ж϶Դ�    
    if (matrix(i,3)==1 && matrix(i,4)==1) ||(matrix(i,3)==0 && matrix(i,4)==0)
        matrix(i,5)=1;
    end
    
    %% save
    save(filename,'matrix');
    Screen('close',gratingTexture);                                         % close screen

    
end
%% %%%%%%%%%%%%%%%%%%%%%% ���� %%%%%%%%%%%%%%%%%%%%
    trialtype1 = (find(matrix(:,7)==0)); 
    trialtype2 = (find(matrix(:,7)==1));
    sumtype1=0;   
    sumtype2=0;
    for i=1:trials/2
        sumtype1=sumtype1+matrix(trialtype1(i),6);
    end
  
    for i=1:trials/2
        sumtype2=sumtype2+matrix(trialtype2(i),6);
    end
    RSVPs=(sumtype1+sumtype2)/trials;
    RSVPs=floor(RSVPs);

%% %%%%%%%%%%%%%% ���� %%%%%%%%%%%%%%%%%%%%%%%%%%
Screen('DrawText',w,'The end. Thank You! ',xcenter-150,ycenter, [0 0 0]);
Screen('Flip',w);
WaitSecs(3);
KbWait;
Screen('CloseAll');
Priority(0);
Screen('LoadNormalizedGammaTable',screenNumber,oldclut);
Screen('CloseAll');
ShowCursor; % ��ʾ���


% %% %%%%%%%%%%%%%%%%% ��ͼ %%%%%%%%%%%%%%%%%%%%%%%%%
% trialarray=linspace(1,trials/2,trials/2)
% line1=matrix(trialtype1,6);
% line2=matrix(trialtype2,6);
% plot(trialarray,line1);
% hold on;
% plot(trialarray,line2);

end
