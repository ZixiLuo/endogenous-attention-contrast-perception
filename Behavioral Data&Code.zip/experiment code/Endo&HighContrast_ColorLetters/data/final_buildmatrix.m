function final_buildmatrix(subjectid)
 load([subjectid '_paramatrix']);
 %     %%%%%%%%%%%%%%%ȥ���۶����Դ�%%%%%%%%%%%%%

%                paramatrix(838,:)=[];
%                 paramatrix(826,:)=[];
%              paramatrix(824,:)=[];
%                paramatrix(812,:)=[];
%              paramatrix(810,:)=[];
%              paramatrix(800,:)=[];
%               paramatrix(792,:)=[];
%              paramatrix(765,:)=[];
%             paramatrix(691,:)=[];
%             paramatrix(688,:)=[];
%             paramatrix(682,:)=[];
%             paramatrix(594,:)=[];
%             paramatrix(586,:)=[];
%           paramatrix(562,:)=[];
%         paramatrix(561,:)=[];
%           paramatrix(550,:)=[];
%          paramatrix(542,:)=[];
%           paramatrix(538,:)=[];
%           paramatrix(530,:)=[];
%          paramatrix(466,:)=[];
%           paramatrix(456,:)=[];
%          paramatrix(331,:)=[];
%         paramatrix(325,:)=[];
%          paramatrix(291,:)=[];
%          paramatrix(253,:)=[];
%          paramatrix(209,:)=[];
%        paramatrix(104,:)=[];
%         paramatrix(91,:)=[];
%         paramatrix(90,:)=[];
%          paramatrix(75,:)=[];
%          paramatrix(73,:)=[];
%         paramatrix(62,:)=[];
%         paramatrix(40,:)=[];
%         paramatrix(36,:)=[];
%         paramatrix(27,:)=[];
%        paramatrix(19,:)=[];
%        paramatrix(17,:)=[];
%        paramatrix(5,:)=[];
%        paramatrix(3,:)=[];
%       paramatrix(58,:)=[];
%       paramatrix(53,:)=[];
%       paramatrix(52,:)=[];
%       paramatrix(45,:)=[];
%       paramatrix(33,:)=[];
%       paramatrix(32,:)=[];
%       paramatrix(31,:)=[];
%       paramatrix(27,:)=[];
%       paramatrix(26,:)=[];
%       paramatrix(20,:)=[];
%       paramatrix(16,:)=[];
%       paramatrix(15,:)=[];
%       paramatrix(14,:)=[];
%       paramatrix(13,:)=[];
%       paramatrix(12,:)=[];
%       paramatrix(11,:)=[];
%       paramatrix(8,:)=[];
%       paramatrix(4,:)=[];
%       paramatrix(2,:)=[];
%% save
    filename = ['final_',subjectid,'_paramatrix'];
    save(filename,'paramatrix');
    clear
end

