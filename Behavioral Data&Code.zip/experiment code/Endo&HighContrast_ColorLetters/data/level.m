function[level]=level(subjectid)
 

load([subjectid '_paramatrix']);

%%%%%%%%%%%%%%%%去除眼动的试次%%%%%%%%%%%%%
%      paramatrix(817,:)=[];
%       paramatrix(792,:)=[];
%        paramatrix(763,:)=[];
%     paramatrix(732,:)=[];
%      paramatrix(693,:)=[];
%      paramatrix(687,:)=[];



id=paramatrix(:,17)==-1;
paramatrix(id,:)=[];
level=[];
level(:,1)=unique(paramatrix(find(paramatrix(:,6)==-1),9));%%stim strength
level(:,2)=unique(paramatrix(find(paramatrix(:,6)==0),9));
level(:,3)=unique(paramatrix(find(paramatrix(:,6)==1),9));





       
    