function[Catchtrial_Percent]=Catchtrial_Ratio(subjectid)
 

load([subjectid '_paramatrix']);

%%%%%%%%%%%%%%%%去除眼动的试次%%%%%%%%%%%%%
%      paramatrix(817,:)=[];
%       paramatrix(792,:)=[];
%        paramatrix(763,:)=[];
%     paramatrix(732,:)=[];
%      paramatrix(693,:)=[];
%      paramatrix(687,:)=[];


Catchtrial_Num=length(find(paramatrix(:,17)==-1));

Catchtrial_Correctness=length(find(paramatrix(:,17)==-1&paramatrix(:,8)==paramatrix(:,11)));
Catchtrial_Percent=Catchtrial_Correctness/Catchtrial_Num;


       
    