% subjects={'lihaipan','yulingxia','zhujiahuan','liyi','luzhou','mayinuo',...
%     'zhouzhirong','tanlinghui','jinderui','zhangpuyuan','youjienan','chenlingyan','wangke','gongliangyu'};
%exp15a

% subjects={'caiyongchun01','heluling','heyihui','yulingxia','xueyaoting','litongtong','chujialei',...
%     'feijingyi','zhaochang','donghang','zhusongbo','tanglin'}; %exp15b_2

% subjects={'panhaozi','gongliangyu','zhujiahuan','xuwang','wangyanni','huangluchen','duhaowei',...
%     'jianghan','xianghongyu','yangyumei01','yangzijing','yeqihang'};
%     %exp15c_2

% subjects={'liangziyue','caiyongchun','liang','heyihui','yangyumei','liuziwei','zhangfang',...
%     'yangzijing','wanglixin','tanlinghui','zhuzhen'}; %exp15d


% subjects = dir('102_1_*_paramatrix.mat'); %������������ʽʵ��������������õ�
% subjects = dir('930_*_paramatrix.mat'); %������Ϊ������ǰ�����ݵ����õģ���ʹ����������ע�͵���ɾ������
subjects1 = dir('1*_paramatrix.mat');
subjects2 = dir('930_*_paramatrix.mat');
subjects = [subjects1;subjects2];

numofsub=length(subjects);
s_FittingPointMatrix=[];
t_FittingPointMatrix=[];
s_RawdataPointMatrix=[];
t_RawdataPointMatrix=[];

%%����standrad cue(ԭ��Ϊinvalid)����µ����ƽ������
for i=1:numofsub
    subjectallid=subjects(i).name;
    id_split = strsplit(subjectallid,'_500_paramatrix');
    subjectid = char(id_split(1));
    load(['s_' subjectid '_FittingPoint']);
    m = 1;
    rownum = 0;
    rownumup = 1;
    rownumdown = 879;
    if i==1
        s_FittingPointMatrix(:,1)=log10(0.09):0.001:log10(0.68); % 10.^FittingPoint(:,1)
    end
    rownum = size(FittingPoint,1);
    for m = 1:879
        if s_FittingPointMatrix(m,1) == FittingPoint(1,1)
            rownumup = m;
            break;
        end
    end
    for m = 1:879
        if s_FittingPointMatrix(m,1) == FittingPoint(rownum,1);
            rownumdown = m;
            break;
        end
    end
    s_FittingPointMatrix(:,i+1) = nan;
    s_FittingPointMatrix(rownumup:rownumdown,i+1) = FittingPoint(:,2);
end
s_MeanFittingPoint(:,1)= s_FittingPointMatrix(:,1); %����ֵ
s_MeanFittingPoint(:,2)= mean(s_FittingPointMatrix(:,2:(numofsub+1)),2,'omitnan'); %ƽ��ֵ
s_MeanFittingPoint(:,3)= std(s_FittingPointMatrix(:,2:(numofsub+1)),0,2,'omitnan')/sqrt(numofsub-1); %standard error

%%����test cue(ԭ��Ϊvalid)����µ����ƽ������
for i=1:numofsub
    subjectallid=subjects(i).name;
    id_split = strsplit(subjectallid,'_500_paramatrix');
    subjectid = char(id_split(1));
    load(['t_' subjectid '_FittingPoint']);
    m = 1;
    rownum = 0;
    rownumup = 1;
    rownumdown = 879;
    if i==1
        t_FittingPointMatrix(:,1)=log10(0.09):0.001:log10(0.68); % 10.^FittingPoint(:,1)
    end
    rownum = size(FittingPoint,1);
    for m = 1:879
        if t_FittingPointMatrix(m,1) == FittingPoint(1,1)
            rownumup = m;
            break;
        end
    end
    for m = 1:879
        if t_FittingPointMatrix(m,1) == FittingPoint(rownum,1);
            rownumdown = m;
            break;
        end
    end
    t_FittingPointMatrix(:,i+1) = nan;
    t_FittingPointMatrix(rownumup:rownumdown,i+1)=FittingPoint(:,2);
end
t_MeanFittingPoint(:,1)= t_FittingPointMatrix(:,1); %����ֵ
t_MeanFittingPoint(:,2)= mean(t_FittingPointMatrix(:,2:(numofsub+1)),2,'omitnan'); %ƽ��ֵ
t_MeanFittingPoint(:,3)= std(t_FittingPointMatrix(:,2:(numofsub+1)),0,2,'omitnan')/sqrt(numofsub-1); %standard error

%%����stanndrad cue����µ�ԭʼ���ݵ�ƽ��ֵ
for i=1:numofsub
    subjectallid=subjects(i).name;
    id_split = strsplit(subjectallid,'_500_paramatrix');
    subjectid = char(id_split(1));
    load(['s_' subjectid '_RawdataPoint']);
    if i==1
        s_RawdataPointMatrix(:,1)=[0.0900000000000000;0.110170000000000;0.134860000000000;0.165090000000000;0.202090000000000;0.247390000000000;0.302830000000000;0.370710000000000;0.453790000000000;0.555500000000000;0.680000000000000]; % RawdataPoint(:,1)
    end
    rownum = size(RawdataPoint,1);
    s_RawdataPointMatrix(:,i+1) = nan;
    for m = 1:rownum
        for n = 1:11
            if s_RawdataPointMatrix(n,1) == RawdataPoint(m,1)
                s_RawdataPointMatrix(n,i+1)=RawdataPoint(m,2);
            end
        end
    end
end
s_MeanRawdataPoint(:,1)= s_RawdataPointMatrix(:,1); %����ֵ
s_MeanRawdataPoint(:,2)= mean(s_RawdataPointMatrix(:,2:(numofsub+1)),2,'omitnan'); %ƽ��ֵ
s_MeanRawdataPoint(:,3)= std(s_RawdataPointMatrix(:,2:(numofsub+1)),0,2,'omitnan')/sqrt(numofsub-1); %standard error

%%����test cue����µ�ԭʼ���ݵ�ƽ��ֵ
for i=1:numofsub
    subjectallid=subjects(i).name;
    id_split = strsplit(subjectallid,'_500_paramatrix');
    subjectid = char(id_split(1));
    load(['t_' subjectid '_RawdataPoint']);
    if i==1
      t_RawdataPointMatrix(:,1)=[0.0900000000000000;0.110170000000000;0.134860000000000;0.165090000000000;0.202090000000000;0.247390000000000;0.302830000000000;0.370710000000000;0.453790000000000;0.555500000000000;0.680000000000000]; % RawdataPoint(:,1)
    end
    t_RawdataPointMatrix(:,i+1) = nan;
    rownum = size(RawdataPoint,1);
    for m = 1:rownum
        for n = 1:11
            if t_RawdataPointMatrix(n,1) == RawdataPoint(m,1)
                t_RawdataPointMatrix(n,i+1)=RawdataPoint(m,2);
            end
        end
    end
end
t_MeanRawdataPoint(:,1)= t_RawdataPointMatrix(:,1); %����ֵ
t_MeanRawdataPoint(:,2)= mean(t_RawdataPointMatrix(:,2:(numofsub+1)),2,'omitnan'); %ƽ��ֵ
t_MeanRawdataPoint(:,3)= std(t_RawdataPointMatrix(:,2:(numofsub+1)),0,2,'omitnan')/sqrt(numofsub-1); %standard error

t_linecolorr=[1 0 0];
s_linecolorr=[0 0 1];
t_dotcolorr=[0.8 0.4 0.4];
s_dotcolorr=[0.5 0.5 0.8];

hold on
plot(10.^s_MeanFittingPoint(:,1),s_MeanFittingPoint(:,2),'LineWidth',1.5,'Color',s_linecolorr);
plot(10.^t_MeanFittingPoint(:,1),t_MeanFittingPoint(:,2),'LineWidth',1.5,'Color',t_linecolorr);

scatter(s_MeanRawdataPoint(:,1),s_MeanRawdataPoint(:,2),150,'ro','MarkerFaceColor',s_dotcolorr,'MarkerEdgeColor','none');
scatter(t_MeanRawdataPoint(:,1),t_MeanRawdataPoint(:,2),150,'ro','MarkerFaceColor',t_dotcolorr,'MarkerEdgeColor','none');

errorbar(s_MeanRawdataPoint(:,1),s_MeanRawdataPoint(:,2),s_MeanRawdataPoint(:,3),'.b','LineWidth',0.5)
errorbar(t_MeanRawdataPoint(:,1),t_MeanRawdataPoint(:,2),t_MeanRawdataPoint(:,3),'.r','LineWidth',0.5)

xlabel('Gray level','FontSize',14)
ylabel('''same'' response (%)','FontSize',14)

% line([160 160],[0.9 0],'color',[0.5 0.5 0.5],'LineStyle','-','LineWidth',0.5)  %��֪��Ϊʲô��������Ҫע�͵�����Ȼ������ǳ�Զ

s_maxEJratio=max(s_MeanFittingPoint(:,2));%y��������ֵ
s_PSEindex=find(s_MeanFittingPoint(:,2)==s_maxEJratio);
s_PSE=s_MeanFittingPoint(s_PSEindex,1);%�ҵ���Ӧ��x
% line([i_PSE i_PSE],[i_maxEJratio 0],'color',i_dotcolorr,'LineStyle','--')
%line([i_PSE i_PSE],[0.9 0],'color',i_dotcolorr,'LineStyle','--','LineWidth',2)
%text(i_PSE,0.05,num2str(i_PSE,'%4.3g'))

t_maxEJratio=max(t_MeanFittingPoint(:,2));%y��������ֵ
t_PSEindex=find(t_MeanFittingPoint(:,2)==t_maxEJratio);
t_PSE=t_MeanFittingPoint(t_PSEindex,1);%�ҵ���Ӧ��x
% line([v_PSE v_PSE],[v_maxEJratio 0],'color',v_dotcolorr,'LineStyle','--')
%line([v_PSE v_PSE],[0.9 0],'color',v_dotcolorr,'LineStyle','--','LineWidth',2)
%text(v_PSE,0.05,num2str(v_PSE,'%4.3g'))

%axes('LineWidth',2)

hold off

